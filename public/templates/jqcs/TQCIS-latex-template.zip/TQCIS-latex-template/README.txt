Transactions on Quantum Computing and Information Security (TQCIS) -- LaTeX manuscript template
NextGenIQ Press

Files
  manuscript.tex             the manuscript; start here
  titlepage.tex          author details, submitted separately for double-blind review
  references.bib         your references (BibTeX)
  nextgeniq.cls          the class file; do not edit
  nextgeniq-logo.png     used on the first page

Overleaf
  New Project > Upload Project, and choose this zip file. Overleaf compiles
  it with pdfLaTeX and BibTeX without further setup.

On your own computer
  pdflatex manuscript && bibtex manuscript && pdflatex manuscript && pdflatex manuscript

Class options
  anonymous   hides the author block for double-blind review (keep it on for submission)
  lineno      line numbers for reviewers
  numbered    Citations are numbered ([1], [2]) in order of first citation.

Use only standard packages. Submit the .tex, .bib and figure files with the
compiled PDF.
