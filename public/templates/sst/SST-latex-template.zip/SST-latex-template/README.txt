Security, Safety & Trust Magazine (SST) -- LaTeX magazine article template
NextGenIQ Press

Files
  article.tex             the magazine article; start here
  titlepage.tex          author details, submitted separately for double-blind review
  references.bib         your references (BibTeX)
  nextgeniq.cls          the class file; do not edit
  nextgeniq-logo.png     used on the first page
  article.pdf             the template compiled, for reference

Overleaf
  New Project > Upload Project, and choose this zip file. Overleaf compiles
  it with pdfLaTeX and BibTeX without further setup.

On your own computer
  pdflatex article && bibtex article && pdflatex article && pdflatex article

Class options
  anonymous   hides the author block for double-blind review (keep it on for submission)
  magazine    two columns, 10pt, numbered headings: the magazine page.
              Articles must fit in 5 pages of this layout, with no more
              than 6 figures and tables, 3 displayed equations and 15
              references. The sidebar environment boxes background text,
              and algorithmbox sets a numbered algorithm.
  lineno      line numbers for reviewers
  numbered    Citations are numbered ([1], [2]) in order of first citation.

Use only standard packages. Submit the .tex, .bib and figure files with the
compiled PDF.
