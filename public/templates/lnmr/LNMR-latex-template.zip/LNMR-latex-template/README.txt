Lecture Notes in Multidisciplinary Research (LNMR) -- LaTeX chapter template
NextGenIQ Press

Files
  chapter.tex             the chapter; start here
  references.bib         your references (BibTeX)
  nextgeniq.cls          the class file; do not edit
  nextgeniq-logo.png     used on the first page
  chapter.pdf             the template compiled, for reference

Overleaf
  New Project > Upload Project, and choose this zip file. Overleaf compiles
  it with pdfLaTeX and BibTeX without further setup.

On your own computer
  pdflatex chapter && bibtex chapter && pdflatex chapter && pdflatex chapter

Class options
  chapter     chapter layout, with the volume title on the first page
  lineno      line numbers for reviewers
  authoryear  Citations are author-date, (Smith & Brown, 2024), with references listed alphabetically.

Use only standard packages. Submit the .tex, .bib and figure files with the
compiled PDF.
