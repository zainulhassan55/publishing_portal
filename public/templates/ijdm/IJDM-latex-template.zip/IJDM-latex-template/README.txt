International Journal of Digital Management (IJDM) -- LaTeX manuscript template
NextGenIQ Press

Files
  manuscript.tex             the manuscript; start here
  titlepage.tex          author details, submitted separately for double-blind review
  references.bib         your references (BibTeX)
  nextgeniq.cls          the class file; do not edit
  nextgeniq-logo.png     used on the first page
  manuscript.pdf             the template compiled, for reference

Overleaf
  New Project > Upload Project, and choose this zip file. Overleaf compiles
  it with pdfLaTeX and BibTeX without further setup.

On your own computer
  pdflatex manuscript && bibtex manuscript && pdflatex manuscript && pdflatex manuscript

Class options
  anonymous   hides the author block for double-blind review (keep it on for submission)
  lineno      line numbers for reviewers
  authoryear  Citations are author-date, (Smith & Brown, 2024), with references listed alphabetically.

Use only standard packages. Submit the .tex, .bib and figure files with the
compiled PDF.
